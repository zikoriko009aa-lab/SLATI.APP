package ma.slati

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import kotlinx.coroutines.*
import java.time.*

object Scheduler {
    val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    /** يجدول تنبيهين لكل صلاة لثلاثة أيام قادمة. رمز الطلب فريد لكل (يوم، صلاة، نوع) فلا تتكرر التنبيهات. */
    suspend fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val before = Settings.flag(ctx, "before"); val after = Settings.flag(ctx, "after")
        Db.get(ctx).dao().upcoming(LocalDate.now().toString(), 3).forEach { day ->
            val date = LocalDate.parse(day.date)
            day.list().forEachIndexed { idx, t ->
                val ms = LocalDateTime.of(date, LocalTime.parse(t.padStart(5, '0')))
                    .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                set(ctx, am, date, idx, 0, ms - 15 * 60_000, before)
                set(ctx, am, date, idx, 1, ms + 10 * 60_000, after)
            }
        }
    }

    private fun set(ctx: Context, am: AlarmManager, d: LocalDate, idx: Int, kind: Int, at: Long, on: Boolean) {
        val code = (d.toEpochDay().toInt() * 10 + idx) * 2 + kind
        val pi = PendingIntent.getBroadcast(ctx, code,
            Intent(ctx, AlarmReceiver::class.java).putExtra("idx", idx).putExtra("kind", kind).putExtra("code", code),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (!on || at <= System.currentTimeMillis()) { am.cancel(pi); return }
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val name = Scheduler.names[i.getIntExtra("idx", 0)]
        val (title, text) = if (i.getIntExtra("kind", 0) == 0)
            "اقترب وقت الصلاة" to "استعد للصلاة، اقترب موعد صلاة $name. لا تنسَ الاستعداد للقاء الله."
        else "لا تنسى أذكار الصلاة" to "حان وقت أذكار ما بعد صلاة $name. لا تنسَ ذكر الله."
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("slati", "تنبيهات الصلاة", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(i.getIntExtra("code", 0), NotificationCompat.Builder(c, "slati")
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setContentIntent(open)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = goAsync()
        CoroutineScope(Dispatchers.IO).launch { try { Scheduler.scheduleAll(c.applicationContext) } finally { p.finish() } }
    }
}

class SyncWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        Repo.refresh(applicationContext); Scheduler.scheduleAll(applicationContext); return Result.success()
    }
}
