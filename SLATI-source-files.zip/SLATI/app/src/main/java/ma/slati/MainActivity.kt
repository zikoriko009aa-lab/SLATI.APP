package ma.slati

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.hardware.*
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.*
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.*

val Green = Color(0xFF0B3D20); val Deep = Color(0xFF06281A); val Gold = Color(0xFFD4AF37)
val Cream = Color(0xFFFBF6E9); val Ok = Color(0xFF1E8E3E); val Soft = Color(0xFFFFE9B0)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("sync", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS).build())
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { MaterialTheme { App() } }
        }
    }
}

fun saveLocationOnce(ctx: Context) {
    try {
        val lm = ctx.getSystemService(LocationManager::class.java)
        lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
            ?.let { Settings.setLoc(ctx, it.latitude, it.longitude) }
    } catch (e: SecurityException) { }
}

@Composable fun App() {
    var tab by remember { mutableStateOf(2) }
    val tabs = listOf("القبلة" to "🕋", "الأدعية" to "📖", "الرئيسية" to "🏠", "إحصائيات" to "📊", "المزيد" to "☰")
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    // الموقع يُطلب مرة واحدة فقط ثم يُحفظ؛ بعدها لا يُطلب ولا يُقرأ مجدداً
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) saveLocationOnce(ctx) }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (!Settings.hasLoc(ctx)) locPerm.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
    Scaffold(containerColor = Deep, bottomBar = {
        NavigationBar(containerColor = Deep) {
            tabs.forEachIndexed { i, (n, e) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e) },
                    label = { Text(n, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedTextColor = Gold, unselectedTextColor = Color.White, indicatorColor = Green))
            }
        }
    }) { pad -> Box(Modifier.padding(pad).fillMaxSize()) {
        when (tab) { 0 -> Qibla(); 1 -> Adhkar(); 2 -> Home(); 3 -> Stats(); else -> More() }
    } }
}

private val hijriMonths = listOf("محرم","صفر","ربيع الأول","ربيع الآخر","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة")
/** يوم التطبيق ينتهي عند الساعة 4 صباحاً */
fun appDay(): LocalDate = LocalDateTime.now().minusHours(4).toLocalDate()

private val fmtHm = DateTimeFormatter.ofPattern("HH:mm")
private fun hm(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(fmtHm)

@Composable fun Home() {
    val ctx = LocalContext.current; val dao = remember { Db.get(ctx).dao() }; val scope = rememberCoroutineScope()
    var today by remember { mutableStateOf(appDay().toString()) }
    var t by remember { mutableStateOf<DayTimes?>(null) }
    var failed by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(LocalTime.now()) }
    val logs by remember(today) { dao.logsFor(today) }.collectAsState(emptyList())
    LaunchedEffect(Unit) {
        failed = !Repo.refresh(ctx); t = dao.times(today); Scheduler.scheduleAll(ctx)
        while (true) {
            now = LocalTime.now(); delay(1000)
            val d = appDay().toString()
            if (d != today) {   // تغيّر اليوم: حمّل أوقات اليوم الجديد وأعد الجدولة
                today = d; Repo.refresh(ctx); t = dao.times(d); Scheduler.scheduleAll(ctx)
            }
        }
    }
    val times = t?.list()?.map { LocalTime.parse(it.padStart(5, '0')) }
    val afterMid = LocalDate.now().toString() != today   // بعد منتصف الليل وقبل 4 صباحاً: ما زلنا في يوم أمس
    val next = if (afterMid) -1 else times?.indexOfFirst { it.isAfter(now) } ?: -1
    val h = HijrahDate.from(LocalDate.parse(today))
    Column(Modifier.fillMaxSize().background(Deep)) {
        Column(Modifier.fillMaxWidth().background(Green).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SLATI", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
            Text("صلاتك ... نجاحك في الدنيا والآخرة", color = Gold, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Cream).padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(LocalDate.parse(today).format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.forLanguageTag("ar-MA"))), fontWeight = FontWeight.Bold)
                    Text("${h.get(ChronoField.DAY_OF_MONTH)} ${hijriMonths[h.get(ChronoField.MONTH_OF_YEAR) - 1]} ${h.get(ChronoField.YEAR)} هـ", fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(now.format(fmtHm), fontSize = 30.sp, fontWeight = FontWeight.Black)
                    if (times != null && next >= 0) {
                        val d = Duration.between(now, times[next])
                        Text("${Scheduler.names[next]} بعد ${d.toHours()}:${"%02d".format(d.toMinutes() % 60)}:${"%02d".format(d.seconds % 60)}", color = Ok, fontSize = 12.sp)
                    }
                }
            }
        }
        Text("أوقات الصلاة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
        if (t == null) Text(if (failed) "تعذر جلب الأوقات. تحقق من الاتصال ثم أعد فتح التطبيق." else "جارٍ جلب أوقات وزارة الأوقاف...",
            color = Color.White, modifier = Modifier.padding(16.dp))
        else Column(Modifier.padding(horizontal = 12.dp).clip(RoundedCornerShape(20.dp)).background(Cream)) {
            Scheduler.names.forEachIndexed { i, n ->
                val log = logs.firstOrNull { it.prayer == i }
                val reached = afterMid || !now.isBefore(LocalTime.parse(t!!.list()[i].padStart(5, '0')))
                Row(Modifier.fillMaxWidth().background(if (i == next) Soft else Color.Transparent).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(n, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(t!!.list()[i], fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Column(Modifier.weight(1.2f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Checkbox(checked = log != null, enabled = log != null || reached, colors = CheckboxDefaults.colors(checkedColor = Ok), onCheckedChange = { on ->
                            scope.launch { if (on) dao.putLog(PrayerLog(today, i, System.currentTimeMillis())) else dao.delLog(today, i) }
                        })
                        Text(if (log != null) "تم الصلاة ✓ ${hm(log.doneAt)}" else if (!reached) "لم يحن وقتها" else "لم تُصلَّ بعد",
                            fontSize = 12.sp, color = if (log != null) Ok else Color.DarkGray)
                    }
                }
            }
        }
    }
}

@Composable fun Stats() {
    val ctx = LocalContext.current; val dao = remember { Db.get(ctx).dao() }
    val logs by dao.allLogs().collectAsState(emptyList())
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var picked by remember { mutableStateOf<LocalDate?>(null) }
    val perDay = logs.groupBy { it.date }
    val nowD = appDay()
    val monthCount = logs.count { it.date.startsWith(YearMonth.from(nowD).toString()) }
    val monthPct = monthCount * 100 / (5 * nowD.dayOfMonth)
    val dayPct = (perDay[nowD.toString()]?.size ?: 0) * 100 / 5
    LazyColumn(Modifier.fillMaxSize().padding(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Cream).padding(14.dp), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("${logs.size}" to "إجمالي الصلوات", "${perDay.count { it.value.size == 5 }}" to "أيام كاملة",
                    "$monthCount" to "صلوات الشهر", "$dayPct%" to "اليوم", "$monthPct%" to "الشهر").forEach { (v, l) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(v, fontSize = 20.sp, fontWeight = FontWeight.Black); Text(l, fontSize = 10.sp) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Cream).padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ ym = ym.minusMonths(1) }) { Text("›") }
                    Text("${ym.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("ar-MA"))} ${ym.year}", fontWeight = FontWeight.Bold)
                    TextButton({ ym = ym.plusMonths(1) }) { Text("‹") }
                }
                val offset = (ym.atDay(1).dayOfWeek.value + 1) % 7   // الأسبوع يبدأ بالسبت
                val cells = List(offset) { null } + (1..ym.lengthOfMonth()).map { ym.atDay(it) }
                cells.chunked(7).forEach { w ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        (0 until 7).forEach { c ->
                            val d = w.getOrNull(c)
                            val n = d?.let { perDay[it.toString()]?.size ?: 0 } ?: 0
                            Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(CircleShape)
                                .background(if (d == null) Color.Transparent else if (n == 5) Ok else if (n > 0) Gold else Color(0xFFDDDDDD))
                                .clickable(enabled = d != null) { picked = d }, contentAlignment = Alignment.Center) {
                                if (d != null) Text("${d.dayOfMonth}", color = if (n > 0) Color.White else Color.Black, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
    picked?.let { d ->
        val day = perDay[d.toString()].orEmpty()
        AlertDialog(onDismissRequest = { picked = null }, confirmButton = { TextButton({ picked = null }) { Text("حسناً") } },
            title = { Text(d.toString()) }, text = { Column {
                Scheduler.names.forEachIndexed { i, n ->
                    val l = day.firstOrNull { it.prayer == i }
                    Text("$n: " + (if (l != null) "✓ ${hm(l.doneAt)}" else "—"), modifier = Modifier.padding(2.dp))
                } } })
    }
}

data class Dhikr(val cat: String, val text: String, val n: Int)
val adhkar = listOf(
    Dhikr("الصباح", "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", 1),
    Dhikr("المساء", "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", 1),
    Dhikr("الصباح والمساء", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),
    Dhikr("الصباح والمساء", "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", 3),
    Dhikr("بعد الصلاة", "أَسْتَغْفِرُ اللَّهَ", 3),
    Dhikr("بعد الصلاة", "اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", 1),
    Dhikr("بعد الصلاة", "اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ", 1),
    Dhikr("بعد الصلاة", "سُبْحَانَ اللَّهِ", 33),
    Dhikr("بعد الصلاة", "الْحَمْدُ لِلَّهِ", 33),
    Dhikr("بعد الصلاة", "اللَّهُ أَكْبَرُ", 33),
    Dhikr("قبل الصلاة", "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ (عند دخول المسجد)", 1),
    Dhikr("قبل الصلاة", "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ (عند الخروج من المسجد)", 1),
    Dhikr("من القرآن", "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", 1),
    Dhikr("من القرآن", "رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي ۚ رَبَّنَا وَتَقَبَّلْ دُعَاءِ", 1),
)

@Composable fun Adhkar() {
    var q by remember { mutableStateOf("") }
    var tasbih by remember { mutableStateOf(0) }
    val counts = remember { mutableStateMapOf<Int, Int>() }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
        item {
            OutlinedTextField(q, { q = it }, label = { Text("بحث في الأذكار") }, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp).clip(RoundedCornerShape(16.dp)).background(Green).clickable { tasbih++ }.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text("المسبحة الرقمية (المس للعد)", color = Gold); Text("$tasbih", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                TextButton({ tasbih = 0 }) { Text("صفر", color = Gold) }
            }
        }
        items(adhkar.withIndex().filter { q.isBlank() || it.value.text.contains(q) || it.value.cat.contains(q) }.toList()) { (i, d) ->
            val c = counts[i] ?: 0
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(Cream)
                .clickable { counts[i] = if (c >= d.n) 0 else c + 1 }.padding(14.dp)) {
                Text(d.cat, color = Ok, fontSize = 12.sp)
                Text(d.text, fontSize = 18.sp, lineHeight = 30.sp)
                Text("$c / ${d.n}", fontWeight = FontWeight.Bold, color = if (c >= d.n) Ok else Color.DarkGray)
            }
        }
    }
}

@Composable fun Qibla() {
    val ctx = LocalContext.current
    var az by remember { mutableStateOf(0f) }
    val lat = remember { Settings.lat(ctx) }; val lon = remember { Settings.lon(ctx) }   // الموقع المحفوظ مرة واحدة
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9); val o = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(r, e.values); SensorManager.getOrientation(r, o)
                az = ((Math.toDegrees(o[0].toDouble()) + 360) % 360).toFloat()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { sm.registerListener(l, it, SensorManager.SENSOR_DELAY_UI) }
        onDispose { sm.unregisterListener(l) }
    }
    val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225); val dl = Math.toRadians(39.8262 - lon)
    val bearing = ((Math.toDegrees(atan2(sin(dl) * cos(p2), cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl))) + 360) % 360).toFloat()
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(280.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().rotate(bearing - az), contentAlignment = Alignment.TopCenter) { Text("🕋", fontSize = 48.sp) }
            Text("▲", color = Gold, fontSize = 30.sp)
        }
        Spacer(Modifier.height(16.dp))
        Text("اتجاه القبلة ${bearing.roundToInt()}° من الشمال", color = Color.White, fontSize = 18.sp)
        Text("أدر الهاتف حتى تتجه الكعبة إلى الأعلى", color = Gold, fontSize = 13.sp)
    }
}

@Composable fun More() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val dao = remember { Db.get(ctx).dao() }
    var before by remember { mutableStateOf(Settings.flag(ctx, "before")) }
    var after by remember { mutableStateOf(Settings.flag(ctx, "after")) }
    var cities by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var confirm by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    fun resched() = scope.launch { Scheduler.scheduleAll(ctx) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            @Composable fun sw(label: String, v: Boolean, f: (Boolean) -> Unit) = Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Color.White); Switch(v, f)
            }
            sw("تنبيه قبل الصلاة بـ 15 دقيقة", before) { before = it; Settings.setFlag(ctx, "before", it); resched() }
            sw("تنبيه الأذكار بعد الصلاة بـ 10 دقائق", after) { after = it; Settings.setFlag(ctx, "after", it); resched() }
            Button({ scope.launch { cities = Repo.cities(); if (cities!!.isEmpty()) msg = "تعذر جلب المدن" } }) { Text("اختيار المدينة (وزارة الأوقاف)") }
            Button({ if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) }) { Text("السماح بالمنبهات الدقيقة") }
            Button({ confirm = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))) { Text("إعادة ضبط الإحصائيات") }
            Text(msg, color = Gold)
        }
    }
    cities?.takeIf { it.isNotEmpty() }?.let { list ->
        AlertDialog(onDismissRequest = { cities = null }, confirmButton = {}, title = { Text("اختر مدينتك") }, text = {
            LazyColumn { items(list) { (id, name) ->
                Text(name, Modifier.fillMaxWidth().clickable {
                    Settings.setCity(ctx, id); cities = null
                    scope.launch { msg = if (Repo.refresh(ctx, true)) "تم تحديث الأوقات" else "تعذر التحديث"; resched() }
                }.padding(10.dp))
            } } })
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("حذف كل السجل؟") },
        text = { Text("سيتم حذف سجل الصلوات نهائياً.") },
        confirmButton = { TextButton({ scope.launch { dao.clearLogs() }; confirm = false }) { Text("حذف") } },
        dismissButton = { TextButton({ confirm = false }) { Text("إلغاء") } })
}
