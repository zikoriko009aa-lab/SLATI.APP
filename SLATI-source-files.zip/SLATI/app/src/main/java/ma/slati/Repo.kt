package ma.slati

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.Month

/** أوقات الصلاة من بيانات موقع وزارة الأوقاف (عبر واجهة غير رسمية). */
object Repo {
    const val BASE = "https://habous-prayer-times-api.onrender.com/api/v1/"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 60000; c.readTimeout = 60000   // الخادم المجاني قد يحتاج وقتاً ليستيقظ
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** قائمة المدن: (id, اسم عربي) */
    suspend fun cities(): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        try {
            val a = JSONObject(get(BASE + "available-cities")).getJSONArray("cities")
            (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("id") to o.getString("arabicCityName") } }
        } catch (e: Exception) { emptyList() }
    }

    suspend fun refresh(ctx: Context, force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val dao = Db.get(ctx).dao()
        if (!force && dao.upcoming(LocalDate.now().toString(), 3).size >= 3) return@withContext true
        try {
            val arr = JSONObject(get(BASE + "prayer-times?cityId=" + Settings.city(ctx)))
                .getJSONObject("data").getJSONArray("timings")
            val list = (0 until arr.length()).map {
                val x = arr.getJSONObject(it)
                val g = x.getJSONObject("date").getJSONObject("gregorian")
                val p = x.getJSONObject("prayers")
                val m = g.get("month").toString().let { s -> s.toIntOrNull() ?: Month.valueOf(s.uppercase()).value }
                DayTimes(LocalDate.of(g.getInt("year"), m, g.getInt("day")).toString(),
                    p.getString("fajr"), p.getString("dhuhr"), p.getString("asr"),
                    p.getString("maghrib"), p.getString("ishaa"))
            }
            if (force) dao.clearTimes()
            dao.putTimes(list); true
        } catch (e: Exception) { false }
    }
}
