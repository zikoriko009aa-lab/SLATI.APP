package ma.slati

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "times")
data class DayTimes(@PrimaryKey val date: String, val fajr: String, val dhuhr: String,
                    val asr: String, val maghrib: String, val isha: String) {
    fun list() = listOf(fajr, dhuhr, asr, maghrib, isha)
}

@Entity(tableName = "logs", primaryKeys = ["date", "prayer"])
data class PrayerLog(val date: String, val prayer: Int, val doneAt: Long)

@Dao
interface Dao {
    @Query("SELECT * FROM times WHERE date=:d") suspend fun times(d: String): DayTimes?
    @Query("SELECT * FROM times WHERE date>=:d ORDER BY date LIMIT :n") suspend fun upcoming(d: String, n: Int): List<DayTimes>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTimes(l: List<DayTimes>)
    @Query("DELETE FROM times") suspend fun clearTimes()
    @Query("SELECT * FROM logs WHERE date=:d") fun logsFor(d: String): Flow<List<PrayerLog>>
    @Query("SELECT * FROM logs") fun allLogs(): Flow<List<PrayerLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putLog(l: PrayerLog)
    @Query("DELETE FROM logs WHERE date=:d AND prayer=:p") suspend fun delLog(d: String, p: Int)
    @Query("DELETE FROM logs") suspend fun clearLogs()
}

@Database(entities = [DayTimes::class, PrayerLog::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): Dao
    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context): Db = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "slati.db").build().also { i = it }
        }
    }
}

object Settings {
    private fun p(c: Context) = c.getSharedPreferences("slati", 0)
    fun city(c: Context) = p(c).getString("city", "1")!!          // 1 = الرباط
    fun setCity(c: Context, id: String) = p(c).edit().putString("city", id).apply()
    fun hasLoc(c: Context) = p(c).contains("lat")
    fun lat(c: Context) = p(c).getFloat("lat", 34.02f).toDouble()   // الرباط افتراضياً
    fun lon(c: Context) = p(c).getFloat("lon", -6.83f).toDouble()
    fun setLoc(c: Context, la: Double, lo: Double) = p(c).edit().putFloat("lat", la.toFloat()).putFloat("lon", lo.toFloat()).apply()
    fun flag(c: Context, k: String) = p(c).getBoolean(k, true)    // "before" / "after"
    fun setFlag(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
}
